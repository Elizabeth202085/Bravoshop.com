<?php 

$host="localhost";
$user="root";
$password="";
$db="demo";
$con=mysqli_connect($host,$user,$password,$db);
if(isset($_POST['username'])){
    $uname=$_POST['username'];
    $password=$_POST['password'];
    
    $sql="select * from loginform where User='".$uname."'AND Pass='".$password."' limit 1";
    
    $result=mysqli_query($con,$sql);
    
    if(mysqli_num_rows($result)==1){
        echo " You Have Successfully Logged in";
			header("location:shop");

        exit();
    }
    else{
        echo " You Have Entered Incorrect Password";
        exit();
    }
        
}
?>



















<!DOCTYPE html>
<html>
<head>
	<title> Login Form in HTML5 and CSS3</title>
	<link rel="stylesheet" a href="style.css">
	<link rel="stylesheet" a href="font-awesome.min.css">
</head>
<body>
	<div class="container">
	  <a href="rr.jpg"><img src="rr.jpg" width="1425" height="1926" border="0" lowsrc="rr.jpg"/></a>
	  <form method="POST" action="#">
			<div class="form_input">
			  <input type="text" name="username" placeholder="Enter Your User Name"/>
			</div>
			<div class="form_input">
				<input type="password" name="password" placeholder="Password"/>
			</div>
	        <input type="submit" name="submit" value="LOGIN" class="btn-login"/>
	  </form>
</div>
</body>
</html>
